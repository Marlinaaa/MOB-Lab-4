package me.mahakagg.recipesrecyclerview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class RecipeMethodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_method);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        String item_name = null;
        if (extras != null) {
           item_name = extras.getString(RecipeListAdapter.EXTRA_NAME);
        }
        TextView heading = findViewById(R.id.food_name);
        ImageView imageView = findViewById(R.id.food_image);
        heading.setText(item_name);
        if (item_name != null) {
            switch (item_name){
                case "Mushroom soup":
                    imageView.setImageResource(R.drawable.chocolate_mint_bar);
                    break;
                case "Spaghetti puttanesca":
                    imageView.setImageResource(R.drawable.blueberry_cupcakes);
                    break;
                case "Apple jam":
                    imageView.setImageResource(R.drawable.fudge_brownies);
                    break;

                default: break;
           }
        }
    }
}
